const engineConstants = {
    TILE_SIZE: 10,
};

export { engineConstants };
