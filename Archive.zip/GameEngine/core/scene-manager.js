import { globalGameData } from "../../GameEditor/gameEditor.js";
import { engineConstants } from "../engineConstants.js";
import {
  createCube,
  createPlayer,
  createSceneContainer,
} from "./entity-factory.js";
import { findSpriteById } from "./sprite-manager.js";

let currentScene;

export function initializeGameState(initialGameData) {
  currentScene = initialGameData.scenes[0];
}

export function setCurrentScene(scene) {
  currentScene = scene;
}

export function getCurrentScene() {
  return currentScene;
}

export function loadScene(sceneId) {
  console.log("loadScene:", sceneId);

  // Wait for DOM to be ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => initScene(sceneId));
  } else {
    initScene(sceneId);
  }
}

function initScene(sceneId) {
  const sceneEl = document.querySelector("a-scene");
  if (!sceneEl) {
    console.error("A-Scene not found");
    return;
  }

  // Update current scene
  const newScene = globalGameData.scenes.find(
    (scene) => scene.sceneId === sceneId
  );
  if (!newScene) {
    console.error("Scene not found:", sceneId);
    return;
  }
  currentScene = newScene;

  // Remove existing scene container if it exists
  const existingContainer = document.getElementById("game-scene");
  if (existingContainer) {
    existingContainer.parentNode.removeChild(existingContainer);
  }

  // Create and setup containers
  const sceneContainer = createSceneContainer();
  sceneEl.appendChild(sceneContainer);

  // Add player and lighting
  const playerEl = createPlayer();
  const lightEl = document.createElement("a-light");
  lightEl.setAttribute("type", "ambient");
  lightEl.setAttribute("color", "#FFF");

  sceneContainer.appendChild(playerEl);
  sceneContainer.appendChild(lightEl);

  // Set scene properties
  sceneEl.setAttribute("background", `color: ${newScene.backgroundColor}`);

  // Position player
  const spawnPos = newScene.playerSpawnPosition;
  const gridOffset =
    engineConstants.TILE_SIZE * Math.round(engineConstants.TILE_SIZE / 2);
  playerEl.setAttribute(
    "position",
    `${spawnPos.x * engineConstants.TILE_SIZE - gridOffset} 0 ${
      spawnPos.z * engineConstants.TILE_SIZE - gridOffset
    }`
  );

  // Create scene objects
  newScene.data.forEach((sceneLayer) => {
    sceneLayer.layerData.forEach((row, rowIndex) => {
      row.forEach((cell, cellIndex) => {
        if (cell !== "0") {
          const sprite = findSpriteById(cell);
          if (sprite) {
            createCube(
              cellIndex - Math.floor(sceneLayer.layerData[0].length / 2),
              sceneLayer.layer,
              rowIndex - Math.floor(sceneLayer.layerData.length / 2),
              sprite.id,
              sprite.type
            );
          }
        }
      });
    });
  });

  // Reattach controls to the new player entity
  const leftHand = document.getElementById("leftHand");
  const rightHand = document.getElementById("rightHand");
  if (leftHand && rightHand) {
    leftHand.setAttribute("grid-move", "");
    rightHand.setAttribute("rotation-control", "");
  }
}

export function reloadGame(sceneId = currentScene.sceneId) {
  // If we're in the editor (no a-scene), just update the data
  const sceneEl = document.querySelector("a-scene");
  if (!sceneEl) {
    // We're in editor, just update currentScene
    const newScene = globalGameData.scenes.find(
      (scene) => scene.sceneId === sceneId
    );
    if (newScene) {
      currentScene = newScene;
    }
    return; // Don't try to reload the scene in editor
  }

  // If we're in the game, proceed with scene reload
  const container = document.getElementById("game-scene");
  if (container && container.parentNode) {
    container.parentNode.removeChild(container);
  }
  loadScene(sceneId);
}
